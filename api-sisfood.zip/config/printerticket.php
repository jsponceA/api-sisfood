<?php
return [
    "name" => env("printer_name")
];
